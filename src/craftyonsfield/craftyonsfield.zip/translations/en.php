<?php
/**
 * CraftyonsField plugin for Craft CMS
 *
 * CraftyonsField Translation
 *
 * @author    James Greig
 * @copyright Copyright (c) 2018 James Greig
 * @link      https://www.greig.cc
 * @package   CraftyonsField
 * @since     0.1
 */

return array(
    'Translate me' => 'To this',
);
